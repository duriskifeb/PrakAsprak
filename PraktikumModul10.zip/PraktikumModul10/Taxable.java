package PraktikumModul10;

public interface Taxable {
    double TAX_RATE = 0.1;

    double calculateTax();
}
