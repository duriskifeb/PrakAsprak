package Modul10;

public interface Taxable {
    double TAX_RATE = 0.1;
    double calculateTax();
}
