package Modul10;

public class Makanan {
    
}
