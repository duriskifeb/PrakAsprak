package TestInterfacejava;

public interface Taxable {
    double TAX_RATE = 0.1; // 10% tax rate
    double calculateTax(); //this no implemented
}
