package TestInterfacejava;

public interface Product {
    //ini blom di implementasikan
    double calculatePrice();
    void displayDetail();
}
