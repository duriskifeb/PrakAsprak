package OTWE_UTS;

public class SfMovie extends Movie{
    public SfMovie (String title, String director)  {
        super(title, director, "SF"); //ini super sudah digunakan dengan baik yak
        // sedangkan genre secara otomatis diatur ke “SF” (Science Fiction) 
        // maksud dari itu jadi udh di masukin langsung inputkan SF

    }
}

//parrent child 
//turunan dan induk